const year = document.querySelector('#year');
if (year) year.textContent = new Date().getFullYear();

const items = document.querySelectorAll('.reveal');
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
items.forEach((item) => observer.observe(item));
